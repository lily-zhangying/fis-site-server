
fis.config.merge({
	namespace: 'common',
    pack: {
        '/static/aio.js': '**.js',
        '/static/aio.css': '**.css'
    }
});
