module.exports = {
    echo: function (s) {
        console.log(s);
        console.log('hahahahahahaha');
    }
};