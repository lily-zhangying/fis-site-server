
fis.config.merge({
    namespace: 'index'
});
